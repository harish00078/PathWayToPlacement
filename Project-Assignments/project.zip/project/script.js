let score = 0;
let timer = 60;
let interval;

const scoreDisplay = document.getElementById('score');
const startRulesDiv = document.getElementById('start-rules');
const startScreenDiv = document.getElementById('startScreen');
const quizScreenDiv = document.getElementById('quizScreen');
const endScreenDiv = document.getElementById('endScreen');
const questionDiv = document.getElementById('question');
const answerButtons = document.querySelectorAll('.answer');
const timerDiv = document.getElementById('timer');
const finalScoreDiv = document.getElementById('finalScore');

document.getElementById('startQuiz').addEventListener('click', function () {
    startRulesDiv.style.display = 'none';
    startScreenDiv.classList.add('hidden');
    quizScreenDiv.classList.remove('hidden');
    getQuestion();
    startTimer();
    updateScore();
});

document.getElementById('playAgain').addEventListener('click', function () {
    score = 0;
    timer = 60;
    endScreenDiv.classList.add('hidden');
    quizScreenDiv.classList.remove('hidden');
    getQuestion();
    startTimer();
    updateScore();
});

async function getQuestion() {
    try {
        console.log('Fetching question...');
        const response = await fetch('https://opentdb.com/api.php?amount=1');
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        const data = await response.json();
        console.log('Question fetched:', data);
        const question = data.results[0];
        displayQuestion(question);
    } catch (error) {
        questionDiv.textContent = 'Failed to load question. Please try again.';
        console.error('Fetch error:', error);
    }
}

function displayQuestion(question) {
    questionDiv.innerHTML = question.question;
    const answers = [...question.incorrect_answers, question.correct_answer].sort(() => Math.random() - 0.5);

    answerButtons.forEach((button, index) => {
        button.innerHTML = answers[index];
        button.onclick = () => {
            if (button.innerHTML === question.correct_answer) {
                correctAnswer();
            } else {
                wrongAnswer();
            }
            getQuestion();
        };
    });
}

function correctAnswer() {
    score++;
    updateScore();
}

function wrongAnswer() {
    // Optionally, handle wrong answers (e.g., display feedback)
}

function updateScore() {
    scoreDisplay.textContent = score;
}

function startTimer() {
    clearInterval(interval);  // Clear any previous intervals to avoid multiple timers
    interval = setInterval(() => {
        timer--;
        timerDiv.textContent = `Time left: ${timer} seconds`;
        if (timer <= 0) {
            endGame();
        }
    }, 1000);
}

function endGame() {
    clearInterval(interval);
    quizScreenDiv.classList.add('hidden');
    endScreenDiv.classList.remove('hidden');
    finalScoreDiv.textContent = score;
}
