const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
fileList.style.scrollBehavior = 'smooth';

const MAX_IMAGES = 10;
let imagesData = [];

dropzone.addEventListener('click', () => fileInput.click());

dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
});

dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));

dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

function handleFiles(files) {
    const filesArray = Array.from(files);
    let invalidFileFound = false;

    filesArray.forEach((file) => {
        if (file.type.startsWith('image/')) {
            if (imagesData.length < MAX_IMAGES) {
                displayFile(file);
            } else {
                alert('Maximum number of images reached.');
            }
        } else {
            invalidFileFound = true;
        }
    });

    if (invalidFileFound) {
        alert('not an image');
    }
}

function displayFile(file) {
    const fileReader = new FileReader();
    fileReader.onload = function (event) {
        const fileItem = document.createElement('div');
        fileItem.classList.add('file-item');
        fileItem.innerHTML = `
            <img src="${event.target.result}" alt="${file.name}">
            <input type="checkbox">
            <textarea>${loadDescription(file.name)}</textarea>
            <button class="save-description">Save Description</button>
        `;
        fileList.appendChild(fileItem);

        fileItem.querySelector('.save-description').addEventListener('click', function () {
            const description = fileItem.querySelector('textarea').value;
            saveDescription(file.name, description);
        });
    };
    fileReader.readAsDataURL(file);
}

function saveDescription(fileName, description) {
    const descriptions = JSON.parse(localStorage.getItem('descriptions')) || {};
    descriptions[fileName] = description;
    localStorage.setItem('descriptions', JSON.stringify(descriptions));
}

function loadDescription(fileName) {
    const descriptions = JSON.parse(localStorage.getItem('descriptions')) || {};
    return descriptions[fileName] || '';
}

document.addEventListener('change', function (e) {
    if (e.target.type === 'checkbox') {
        const textarea = e.target.closest('.file-item').querySelector('textarea');
        if (e.target.checked) {
            textarea.disabled = true;
            alert('Checkbox clicked');
        } else {
            textarea.disabled = false;
        }
    }
});
